-- Astra: midnight / violet / ice
hl.config({
    general = {
        gaps_in = 6, gaps_out = 14, border_size = 2,
        col = {
            active_border = { colors = {"rgba(a78bfaff)", "rgba(7dd3fcff)"}, angle = 45 },
            inactive_border = "rgba(29334bcc)",
        },
        resize_on_border = true,
    },
    decoration = {
        rounding = 16,
        shadow = { enabled = true, range = 20, render_power = 3, color = 0x55050812 },
        blur = { enabled = true, size = 6, passes = 2, vibrancy = 0.15 },
    },
})
