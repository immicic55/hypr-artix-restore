-- Infinite horizontal tiling, with a persistent switch to regular tiling.
local mode = "scrolling"
local saved = io.open(os.getenv("HOME") .. "/.config/hypr/layout-mode", "r")
if saved then
    local value = saved:read("*l")
    saved:close()
    if value == "dwindle" or value == "scrolling" then mode = value end
end
hl.config({
    general = { layout = mode },
    scrolling = {
        column_width = 0.5,
        fullscreen_on_one_column = true,
    },
})
hl.bind("SUPER + T", hl.dsp.exec_cmd("$HOME/.local/bin/hypr-layout-toggle"))
-- SUPER + V toggles the focused window's floating mode in hyprland.lua.
-- SUPER + arrow keys move focus along the strip using the existing bindings.
