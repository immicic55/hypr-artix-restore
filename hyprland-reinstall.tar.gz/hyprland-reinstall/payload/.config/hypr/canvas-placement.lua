-- New GUI windows get a crosshair rectangle selector in canvas mode.
-- Observe mapping instead of wrapping commands, so launcher and keybinds work.
hl.on("window.open", function(window)
    local address = tostring(window.address)
    if not address:match("^0x%x+$") then return end
    hl.exec_cmd("$HOME/.local/bin/hypr-canvas-place " .. address ..
        " >> $HOME/.local/state/hypr-rice/canvas-placement.log 2>&1")
end)
-- Allow the same rectangle placement on the currently focused window.
hl.bind("SUPER + CTRL + R", function()
    local window = hl.get_active_window()
    if window then
        local address = tostring(window.address)
        if address:match("^0x%x+$") then
            hl.exec_cmd("$HOME/.local/bin/hypr-canvas-place " .. address ..
                " >> $HOME/.local/state/hypr-rice/canvas-placement.log 2>&1")
        end
    end
end)
