-- Dark monochrome glass. Loaded after the main configuration.
hl.config({
    general = {
        gaps_in = 4, gaps_out = 10, border_size = 1,
        col = {
            active_border = { colors = {"rgba(ffffffaa)", "rgba(ffffff33)"}, angle = 135 },
            inactive_border = "rgba(ffffff22)",
        },
        resize_on_border = true,
    },
    decoration = {
        rounding = 0,
        rounding_power = 2,
        active_opacity = 1.0,
        inactive_opacity = 0.97,
        shadow = { enabled = true, range = 24, render_power = 3, color = 0x55000000 },
        blur = {
            enabled = true, size = 6, passes = 3,
            vibrancy = 0.0, brightness = 1.0, contrast = 1.0,
        },
    },
})
-- iOS-inspired motion: restrained springs, card zooms, and quick fades.
hl.config({ animations = { enabled = true } })
-- Slightly underdamped for a small bounce before settling.
hl.curve("iosSpring", { type = "spring", mass = 1, stiffness = 230, dampening = 18 })
hl.curve("iosGlide", { type = "spring", mass = 1, stiffness = 260, dampening = 32 })
hl.curve("iosEase", { type = "bezier", points = { {0.22, 1}, {0.36, 1} } })
hl.curve("iosClose", { type = "bezier", points = { {0.4, 0}, {0.8, 0.35} } })
hl.curve("iosFade", { type = "bezier", points = { {0.2, 0}, {0.2, 1} } })

local function ease(leaf, duration, curve, style)
    hl.animation({ leaf = leaf, enabled = true, speed = duration, bezier = curve, style = style })
end
local function spring(leaf, duration, curve, style)
    hl.animation({ leaf = leaf, enabled = true, speed = duration, spring = curve, style = style })
end

ease("global", 4, "iosEase")
spring("windows", 4.5, "iosSpring", "popin 86%")
spring("windowsIn", 4.5, "iosSpring", "popin 86%")
ease("windowsOut", 2.2, "iosClose", "popin 90%")
spring("windowsMove", 3.4, "iosGlide")
ease("fade", 2.2, "iosFade")
ease("fadeIn", 2.2, "iosFade")
ease("fadeOut", 1.8, "iosClose")
ease("border", 2.4, "iosEase")

-- Matching children are explicit because the main config defines them too.
for _, leaf in ipairs({ "workspaces", "workspacesIn", "workspacesOut" }) do
    spring(leaf, 4.5, "iosGlide", "slide")
end
for _, leaf in ipairs({ "specialWorkspace", "specialWorkspaceIn", "specialWorkspaceOut" }) do
    spring(leaf, 4, "iosSpring", "slidevert")
end
spring("layers", 3.8, "iosSpring", "popin 94%")
spring("layersIn", 3.8, "iosSpring", "popin 94%")
ease("layersOut", 2, "iosClose", "popin 96%")
ease("fadeLayers", 2.2, "iosFade")
ease("fadeLayersIn", 2.2, "iosFade")
ease("fadeLayersOut", 1.8, "iosClose")
spring("zoomFactor", 4, "iosGlide")

-- Frost translucent layer surfaces; skip fully transparent margins.
for _, namespace in ipairs({ "waybar", "launcher", "notifications" }) do
    hl.layer_rule({
        name = "glass-" .. namespace,
        match = { namespace = "^" .. namespace .. "$" },
        blur = true,
        ignore_alpha = 0.05,
    })
end
