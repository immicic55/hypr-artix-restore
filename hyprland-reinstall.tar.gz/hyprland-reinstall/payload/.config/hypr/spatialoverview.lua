-- Phantomat: a zoomable, infinite-canvas window manager for Hyprland 0.56+ (made on Omarchy).
--
--   SUPER + CTRL + G   the zoomed-out canvas; type to search, Enter to go
--   CTRL + ,           (in the canvas) tune the look live; F1 lists every key
--
-- Edit and run `hyprctl reload`, or tune live: the tuner saves to
-- spatialoverview-tuning.lua next to this file, which is applied last.

local loaded = false
for _, plugin in ipairs(hl.get_loaded_plugins()) do
  if plugin.name == "spatialoverview" then
    loaded = true
    break
  end
end
-- On the first pass Hyprland has only been told to load the plugin; it
-- parses this file again once the plugin is in. Without the plugin (say,
-- right after a Hyprland update, before a rebuild) nothing here applies.
if not loaded then
  return
end

-- Omarchy's o.bind shows bindings in its key guide; elsewhere, plain binds.
local bind = (o and o.bind) or function(keys, _description, action, opts)
  hl.bind(keys, action, opts)
end

hl.config({
  plugin = {
    spatialoverview = {
      -- Camera / tile geometry
      layout = "grid",
      scale = 0.36,
      workspace_gap = 0,
      grid = {
        columns = 3,
        stagger = 0.0,
      },

      -- Input. Middle-drag pans the world; click selects; dragging into empty
      -- grid territory places a floating window without creating a workspace.
      input = {
        pan_sensitivity = 1.0,
        drag_threshold = 10,
        touchpad_scroll_factor = 1.0,
        scroll_event_delay = 160,
      },

      -- Motion. Edit the `spatialOverviewEase` control points below to shape
      -- acceleration/deceleration without recompiling the plugin.
      animation = {
        enabled = true,
        speed = 4.5,
        bezier = "spatialOverviewEase",
      },

      -- Final overview-only lens pass. `strength` is signed, so negative
      -- values reverse the curvature.
      distortion = {
        enabled = false,
        strength = 0.0,
        edge_scale = 1.08,
        feather = 0.025,
        transition_power = 1.0,
        edge_blur = 0.0,        -- lens blur toward the edges, 0..1
        edge_blur_start = 0.45, -- where it begins: 0 center .. 1 corners
        vignette = 0.0,
        chromatic = 0.0,        -- red/blue fringe toward the edges
      },

      workspace_outline = {
        enabled = false,
        width = 2,
        drop_width = 4,
        rounding = 0,
        opacity = 0.34,
        active_opacity = 0.82,
        drop_opacity = 1.0,
        drop_fill_opacity = 0.12,
      },

      canvas = {
        enabled = true,
        desktop_mode = true,
        persistent = true,
        initial_zoom = 0.72,
        min_zoom = 0.05,
        max_zoom = 2.5,
        zoom_step = 0.12,
        auto_float = true,
        auto_place = true,
        placement_gap = 40,
        space_pan = false,
        direct_input = true,
        hover_focus = true,
        minimap_enabled = true,
        minimap_width = 240,
        minimap_height = 150,
        minimap_margin = 24,
        minimap_opacity = 0.72,
        arrange_context_grouping = true,
        arrange_size_similarity = 0.12,
        arrange_resize_limit = 0.15,
        grid_enabled = true,
        grid_size = 80,
        grid_width = 1,
        grid_opacity = 0.08,
        grid_style = 1, -- 0 lines, 1 dots
        grid_dot_size = 1.5,
        background_dim = 0.35,
        viewport_enabled = false,
        viewport_width = 3,
        viewport_rounding = 0,
        viewport_border_opacity = 0.90,
        viewport_outside_opacity = 0.26,
        float_on_drag = true,
        allow_window_overflow = true,
        snap_viewport_on_pan = true,
        commit_viewport_on_close = true,
        snap_enabled = true,
        remember_layout = true, -- windows keep their spots across restarts
      },

      -- Type-to-search palette in the zoomed-out canvas.
      navigator = {
        enabled = true,
        labels = true,          -- window titles on the map
        dim_unmatched = 0.7,    -- how far non-matching windows recede (0..1)
        pointer = true,         -- click lands, drag moves or pans, wheel zooms
        accent = "#e8e8e8",     -- selected row, caret, key names; #rrggbb, a preset (cyan, violet, ...) or "auto" for the theme
        mono_font = "JetBrainsMono Nerd Font", -- the whole HUD is set in this

        -- Look (feature level 3). All of these are also in the live tuner.
        hud_scale = 1.0,
        width = 720,
        top = 0.075,
        rows = 6,
        row_height = 58,
        rounding = 0,
        panel_opacity = 0.94,
        uppercase = true,
        letter_spacing = 1.0,
        query_size = 17,
        title_size = 14,
        detail_size = 10.5,
        corner_size = 12,
        label_size = 10.5,
        corner_labels = true,
        search_height = 60,
        search_border = 1.5,
        search_border_opacity = 0.85,
        search_border_color = "accent",
        search_glow = 0.0,
      },

      -- The wallpaper as a far layer: it follows the camera at a fraction of
      -- the windows' speed and shrinks a little as you zoom out.
      parallax = {
        enabled = false,
        strength = 0.06,
        depth = 0.12,
        desktop = false,
      },

      chrome_animation = {
        enabled = false,
        top_namespace = "omarchy-bar",
        bottom_namespace = "omarchy-dock",
        top_travel = 1.35,
        bottom_travel = 1.08,
        top_scale = 0.82,
        bottom_scale = 0.92,
        opacity = 0.0,
      },

      wallpaper = 0,
      blur = false,
      blur_strength = 0.7,
      shadow = {
        enabled = false,
        range = 36,
      },
    },
  },
})

hl.curve("spatialOverviewEase", {
  type = "bezier",
  points = { { 0.18, 1.0 }, { 0.32, 1.0 } },
})

-- Monochrome canvas controls; the regular desktop remains available.
function mono_canvas_toggle()
  if pcall(hl.plugin.spatialoverview._dispatch, "canvas", "noop") then
    hl.plugin.spatialoverview._dispatch("overview", "off all")
  else
    hl.plugin.spatialoverview._dispatch("overview", "on all")
  end
end
hl.bind("SUPER + CTRL + C", mono_canvas_toggle)
hl.bind("SUPER + CTRL + ESCAPE", function()
  hl.plugin.spatialoverview._dispatch("overview", "off all")
end)
hl.bind("SUPER + CTRL + G", function()
  hl.plugin.spatialoverview._dispatch("overview", "toggle all")
end)
local function canvas_or(action, fallback)
  return function()
    if not pcall(hl.plugin.spatialoverview._dispatch, "canvas", action) and fallback then
      hl.dispatch(fallback)
    end
  end
end
-- navigate succeeds silently when no canvas exists. Check canvas presence
-- explicitly so normal tiling always receives the focus action when it is off.
function mono_focus(direction)
  if pcall(hl.plugin.spatialoverview._dispatch, "canvas", "noop") then
    hl.plugin.spatialoverview._dispatch("navigate", direction)
  else
    hl.dispatch(hl.dsp.focus({ direction = direction }))
  end
end
for _, direction in ipairs({ "left", "right", "up", "down" }) do
  hl.unbind("SUPER + " .. direction)
  hl.bind("SUPER + " .. direction, function()
    mono_focus(direction)
  end, { repeating = true })
  hl.bind("SUPER + CTRL + " .. direction, canvas_or("pan " .. direction), { repeating = true })
  hl.bind("SUPER + SHIFT + " .. direction, canvas_or("nudge " .. direction,
    hl.dsp.window.swap({ direction = direction })), { repeating = true })
end
hl.bind("SUPER + CTRL + equal", canvas_or("zoom in"), { repeating = true })
hl.bind("SUPER + CTRL + minus", canvas_or("zoom out"), { repeating = true })
hl.bind("SUPER + CTRL + 0", canvas_or("fit"))
hl.bind("SUPER + CTRL + A", canvas_or("arrange"))
-- A floating/tiling toggle would fight the canvas: fill the focused window there.
hl.unbind("SUPER + V")
hl.bind("SUPER + V", canvas_or("fill", hl.dsp.window.float({ action = "toggle" })))
-- Switching tiling layouts also exits the canvas, returning to the normal desktop.
hl.unbind("SUPER + T")
hl.bind("SUPER + T", function()
  if pcall(hl.plugin.spatialoverview._dispatch, "canvas", "noop") then
    hl.plugin.spatialoverview._dispatch("overview", "off all")
    hl.exec_cmd("sleep 0.5; $HOME/.local/bin/hypr-layout-toggle")
  else
    hl.exec_cmd("$HOME/.local/bin/hypr-layout-toggle")
  end
end)
