-- Screenshot and recording controls.
hl.unbind("Print")
hl.bind("Print", hl.dsp.exec_cmd("$HOME/.local/bin/hypr-screenshot region"))
hl.bind("SUPER + Print", hl.dsp.exec_cmd("$HOME/.local/bin/hypr-screenshot monitor"))
hl.bind("SHIFT + Print", hl.dsp.exec_cmd("$HOME/.local/bin/hypr-screenshot screen"))
hl.bind("SUPER + ALT + R", hl.dsp.exec_cmd("$HOME/.local/bin/hypr-record monitor"))
hl.bind("SUPER + ALT + SHIFT + R", hl.dsp.exec_cmd("$HOME/.local/bin/hypr-record region"))
hl.bind("SUPER + ALT + CTRL + R", hl.dsp.exec_cmd("$HOME/.local/bin/hypr-record monitor --audio"))
