# Astra shortcuts

Super is the Windows key. Super + A opens audio settings; Super + E opens the file manager.

| Shortcut | Action |
| --- | --- |
| Super + Enter | Fish terminal (Kitty) |
| Super + Space / Super + R | Launcher (Fuzzel) |
| Super + Q | Close current window |
| Super + X | Unbound |
| Super + B | Firefox |
| Super + E | File manager |
| Super + A | Audio settings |
| Super + L | Lock screen |
| Super + V | Toggle floating window |
| Super + P | Toggle pseudo tiling |
| Super + J | Toggle split direction |
| Super + arrows | Focus window |
| Super + 1–9 / 0 | Switch workspace 1–10 |
| Super + Shift + 1–9 / 0 | Move window to workspace 1–10 |
| Super + S | Toggle scratchpad |
| Super + Shift + S | Move window to scratchpad |
| Super + mouse wheel | Switch workspace |
| Super + left / right drag | Move / resize window |
| Super + M | Exit Hyprland |
| Print | Region screenshot (requires slurp and wl-copy) |

All bindings are together in the KEYBINDINGS section of `~/.config/hypr/hyprland.lua`.

Hardware volume, brightness and media keys retain their existing mappings; missing backend programs are a separate issue.
