#!/usr/bin/env python3
import json, shutil, subprocess
text='󰝟'; tooltip='Audio service unavailable'; status='muted'
if shutil.which('wpctl'):
    try:
        result=subprocess.run(['wpctl','get-volume','@DEFAULT_AUDIO_SINK@'],capture_output=True,text=True,timeout=2)
        if result.returncode == 0:
            muted='MUTED' in result.stdout
            text='󰝟' if muted else '󰕾  '+str(round(float(result.stdout.split()[1])*100))+'%'
            tooltip='Muted' if muted else 'System volume'
            status='muted' if muted else 'active'
    except (subprocess.SubprocessError, ValueError, IndexError):
        pass
print(json.dumps({'text':text,'tooltip':tooltip,'class':status}))
