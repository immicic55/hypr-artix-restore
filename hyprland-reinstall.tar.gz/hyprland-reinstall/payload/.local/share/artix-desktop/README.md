# Artix Hyprland desktop

User configuration is written and Hyprland's configuration validator passed.
System package installation still needs sudo authentication in your terminal:

```sh
~/.local/bin/finish-desktop-setup
```

This installs the desktop/audio packages and their dependencies using a full
Artix upgrade, adds a D-Bus-aware login session, and enables SDDM for next boot.
It does not restart the current desktop or reboot automatically.
After it succeeds, reboot when convenient and select **Hyprland (Artix desktop)**.
Alternatively, from a local TTY run `~/.local/bin/hypr-session`.

## Keys

Super is the Windows key.

| Shortcut | Action |
| --- | --- |
| Super + Enter or Q | Kitty terminal |
| Super + Space or R | Application launcher |
| Super + E | Thunar file manager |
| Super + B | Firefox |
| Super + A | Audio settings |
| Super + L | Lock screen |
| Super + C | Close window |
| Super + V | Toggle floating |
| Super + arrows | Focus window |
| Super + 1–0 | Workspaces 1–10 |
| Super + Shift + 1–0 | Move window to workspace |
| Super + left/right drag | Move/resize window |
| Super + M | Log out (closes session) |
| Print Screen | Select screenshot region; save and copy |
| Volume/mute/brightness keys | Audio and backlight |

Screen locking starts after 10 idle minutes. Keyboard layout is US, matching
the console. Touchpad tap-to-click and natural scrolling are enabled.

## Audio and troubleshooting

PipeWire, WirePlumber, and PipeWire-Pulse start as your user on Hyprland login.
This follows WirePlumber's non-systemd startup ordering:
https://pipewire.pages.freedesktop.org/wireplumber/daemon/running.html
ALSA applications use the installed pipewire-alsa integration.

Open `pavucontrol` to choose the output device, select a sound-card profile,
and inspect application volume and microphone inputs. In a graphical terminal:

```sh
wpctl status
wpctl get-volume @DEFAULT_AUDIO_SINK@
```

Runtime audio, screen sharing, and lock/unlock still require testing after
installation in a real graphical session. This setup session has no access
to the running desktop or audio devices.

Logs: `~/.local/state/hyprland/`. Main configuration:
`~/.config/hypr/hyprland.lua`. Screenshots: `~/Pictures/Screenshots/`.
Portal preferences are in `~/.config/xdg-desktop-portal/hyprland-portals.conf`.
No Bluetooth service or pairing has been configured.
