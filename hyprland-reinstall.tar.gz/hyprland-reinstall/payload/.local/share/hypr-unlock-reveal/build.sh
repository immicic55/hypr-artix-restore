#!/bin/sh
set -eu
cd "$(dirname "$0")"
g++ -shared -fPIC -fno-gnu-unique -std=c++2b -O2 main.cpp -o unlock-reveal.so.next $(pkg-config --cflags hyprland pixman-1 libdrm pangocairo libinput libudev wayland-server xkbcommon lua5.4)
mv unlock-reveal.so.next unlock-reveal.so
