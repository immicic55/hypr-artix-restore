# Unlock reveal

On Hyprland's session-unlock event, the plugin animates visible windows from 90% size and a 28px downward offset, slides Waybar upward from 48px below its final position, and fades background layer surfaces in. It uses the desktop's configured springs and fade curves. Window layout goals, workspaces, focus, fullscreen state, and bar reservations are preserved. No applications or bars are restarted.

Hyprlock uses a darkened, blurred screenshot of the desktop. Its own fade-out is disabled so it releases the screen directly to the live compositor entrance, instead of fading to an old still image. Password authentication remains controlled by Hyprlock.

Build against installed Hyprland headers with `./build.sh`. After updating Hyprland, rebuild and restart the compositor so all plugins match its version. The plugin rejects a mismatched compositor ABI.

`hyprctl dispatch rice-unlock-reveal` previews the motion without unlocking anything. The plugin ignores preview requests during a locked session. Automatic motion also covers idle and suspend locks, since it listens to the compositor rather than a particular locker command.

Remove the `unlock-reveal.so` load line in `~/.config/hypr/hyprland.lua` and run `hyprctl plugin unload "$HOME/.local/share/hypr-unlock-reveal/unlock-reveal.so"` to disable the desktop entrance.
