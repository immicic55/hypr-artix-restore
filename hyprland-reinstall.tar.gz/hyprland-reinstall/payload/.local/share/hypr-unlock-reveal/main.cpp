#include <hyprland/src/plugins/PluginAPI.hpp>
#include <hyprland/src/managers/SessionLockManager.hpp>
#include <hyprland/src/desktop/state/ViewState.hpp>
#include <hyprland/src/desktop/view/Window.hpp>
#include <hyprland/src/desktop/view/LayerSurface.hpp>
#include <hyprland/src/state/MonitorState.hpp>
#include <hyprland/src/output/Monitor.hpp>
#include <hyprland/src/render/Renderer.hpp>
#include <cstdio>
#include <stdexcept>

// Animate rendering geometry only: preserve every window's layout goal,
// workspace, focus, fullscreen state and the bar's exclusive screen area.
static CHyprSignalListener unlockListener;
static void reveal() {
    using namespace Desktop::View;
    int windows = 0, bars = 0, backgrounds = 0;
    for (const auto& w : Desktop::viewState()->windows()) {
        if (!w->m_isMapped || w->isHidden() || w->m_X11DoesntWantBorders)
            continue;
        bool visible = false;
        for (const auto& monitor : State::monitorState()->monitors())
            visible |= w->visibleOnMonitor(monitor);
        if (!visible)
            continue;
        auto ctx = w->m_animationController.animateIn();
        // Gentle pop from below, including for windows with slide rules.
        ctx.size.from = ctx.size.to * 0.9;
        ctx.pos.from = ctx.pos.to + (ctx.size.to - ctx.size.from) / 2.0 + Vector2D{0, 28};
        ctx.alpha.to = w->alpha(WINDOW_ALPHA_FADE)->goal();
        w->m_animationController.apply(ctx);
        ++windows;
    }
    for (const auto& layer : Desktop::viewState()->layers()) {
        if (!layer->m_mapped || !layer->m_monitor)
            continue;
        if (layer->m_namespace == "waybar") {
            auto ctx = layer->m_animationController.animateIn();
            ctx.size.from = ctx.size.to;
            ctx.pos.from = ctx.pos.to + Vector2D{0.0, ctx.size.to.y + 14.0};
            ctx.alpha.to = layer->alpha()[LS_ALPHA_FADE]->goal();
            layer->m_animationController.apply(ctx);
            ++bars;
        } else if (layer->m_layer == 0 || layer->m_namespace == "wallpaper") {
            auto& alpha = layer->alpha()[LS_ALPHA_FADE];
            const auto target = alpha->goal();
            alpha->setValueAndWarp(0.F);
            *alpha = target;
            ++backgrounds;
        }
    }
    for (const auto& monitor : State::monitorState()->monitors())
        g_pHyprRenderer->damageMonitor(monitor);
    std::fprintf(stderr, "[unlock-reveal] animated %d windows, %d bars, %d backgrounds\n", windows, bars, backgrounds);
}
APICALL EXPORT std::string PLUGIN_API_VERSION() { return HYPRLAND_API_VERSION; }
APICALL EXPORT PLUGIN_DESCRIPTION_INFO PLUGIN_INIT(HANDLE handle) {
    if (std::string(__hyprland_api_get_hash()) != __hyprland_api_get_client_hash())
        throw std::runtime_error("Rebuild unlock-reveal for this Hyprland version");
    unlockListener = g_pSessionLockManager->m_events.unlock.listen([] { reveal(); });
    // Explicit preview for isolated testing; never unlocks the session.
    HyprlandAPI::addDispatcherV2(handle, "rice-unlock-reveal", [](std::string) {
        if (!g_pSessionLockManager->isSessionLocked()) reveal();
        return SDispatchResult{};
    });
    return {"unlock-reveal", "Restore desktop with window pop, rising bar and wallpaper fade", "maiake", "1.0"};
}
APICALL EXPORT void PLUGIN_EXIT() { unlockListener.reset(); }
