#!/usr/bin/env python3
"""Restore the desktop snapshot, backing up every replaced path."""
import argparse,json,os,shutil,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--target-home',type=Path,default=Path.home());p.add_argument('--payload',type=Path);args=p.parse_args()
bundle=Path(__file__).resolve().parent
home=args.target_home.resolve();payload=args.payload or bundle/'payload'
paths=json.loads((bundle/'restore-paths.json').read_text())
for rel in paths:
 if Path(rel).is_absolute() or '..' in Path(rel).parts or not (payload/rel).exists():
  raise SystemExit('Invalid or missing snapshot path: '+rel)
backup=home/'.local/state/hyprland-reinstall'/('backup-'+time.strftime('%Y%m%d-%H%M%S')+'-'+str(os.getpid()))
backup.mkdir(parents=True,mode=0o700)
restored=[];saved=[]
try:
 for rel in paths:
  dest=home/rel;src=payload/rel
  # Do not follow an existing parent symlink outside the target home.
  if not dest.parent.resolve().is_relative_to(home):raise RuntimeError('Destination escapes home: '+rel)
  if dest.exists() or dest.is_symlink():
   old=backup/rel;old.parent.mkdir(parents=True,exist_ok=True);shutil.move(str(dest),str(old));saved.append(rel)
  dest.parent.mkdir(parents=True,exist_ok=True)
  restored.append(rel)
  if src.is_dir():shutil.copytree(src,dest)
  else:shutil.copy2(src,dest)
  files=dest.rglob('*') if dest.is_dir() else [dest]
  for f in files:
   if f.is_file() and f.suffix in {'.lua','.jsonc','.conf','.desktop','.ini','.py','.sh','.md','.svg'}:
    try:text=f.read_text()
    except UnicodeError:continue
    if '/home/maiake' in text:f.write_text(text.replace('/home/maiake',str(home)))
except Exception:
 for rel in reversed(restored):
  f=home/rel
  if f.is_dir() and not f.is_symlink():shutil.rmtree(f)
  elif f.exists() or f.is_symlink():f.unlink()
 for rel in reversed(saved):
  f=home/rel;f.parent.mkdir(parents=True,exist_ok=True);shutil.move(str(backup/rel),str(f))
 raise
(backup/'restored-paths.json').write_text(json.dumps(paths,indent=2)+'\n')
print('Desktop restored. Backup: '+str(backup))
