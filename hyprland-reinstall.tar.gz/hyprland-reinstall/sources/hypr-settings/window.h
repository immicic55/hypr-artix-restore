#pragma once
#include <QtWidgets>
#include "backend.h"

class Window : public QMainWindow {
public:
    explicit Window(Backend backend = Backend(), QString config = {});
    void load();
protected:
    void closeEvent(QCloseEvent* event) override;
private:
    Backend backend;
    QString configPath;
    Values current, session;
    QMap<QString, QWidget*> editors;
    QLabel *status, *count;
    QPushButton *applyButton, *saveButton, *undoButton;
    QLineEdit* search;
    QListWidget* navigation;
    QStackedWidget* pages;
    QMap<QString, QList<QWidget*>> rows;
    QVBoxLayout* displayLayout;
    bool loading = false;
    QVariant value(const Setting& setting) const;
    void setValue(const Setting& setting, const QVariant& value);
    Values changes() const;
    void updateState();
    void apply(bool permanent);
    void undo();
    void error(const QString& message);
};
