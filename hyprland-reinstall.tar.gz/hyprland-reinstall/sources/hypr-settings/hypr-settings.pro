QT += widgets
CONFIG += c++17
TARGET = hypr-settings
SOURCES += main.cpp backend.cpp window.cpp
HEADERS += backend.h window.h
QMAKE_CXXFLAGS += -Wall -Wextra
