#include "window.h"

Window::Window(Backend backend, QString config) : backend(std::move(backend)), configPath(std::move(config)) {
    if (configPath.isEmpty()) configPath = QStandardPaths::writableLocation(QStandardPaths::ConfigLocation) + "/hypr/hyprland.lua";
    setWindowTitle("Hyprland Settings");
    setMinimumSize(840, 620);
    resize(1080, 790);
    setStyleSheet(R"(
        QWidget { background: #101521; color: #e3e8f6; font-family: "Noto Sans"; font-size: 13px; }
        QFrame#sidebar { background: #151b2a; border-right: 1px solid #283147; }
        QLabel { background: transparent; }
        QLabel#brand { font-size: 23px; font-weight: 700; color: #c4b5fd; }
        QLabel#heading { font-size: 29px; font-weight: 700; }
        QLabel#muted { color: #9daac2; }
        QListWidget { background: transparent; border: none; outline: none; }
        QListWidget::item { padding: 14px 18px; margin: 3px 12px; border-radius: 8px; }
        QListWidget::item:selected { background: #302d4c; color: #d5caff; }
        QListWidget::item:hover:!selected { background: #20283b; }
        QFrame#card { background: #192132; border: 1px solid #2a344a; border-radius: 10px; }
        QFrame#card QWidget { background: transparent; }
        QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox { background: #101725; border: 1px solid #43516b; border-radius: 6px; padding: 8px; min-height: 20px; }
        QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus, QComboBox:focus { border: 1px solid #b6a0ff; }
        QComboBox QAbstractItemView { background: #20283b; selection-background-color: #514274; }
        QPushButton { background: #252f44; border: 1px solid #3c4861; border-radius: 7px; padding: 10px 16px; }
        QPushButton:hover { background: #34415c; }
        QPushButton#primary { background: #b6a0ff; color: #151025; border: none; font-weight: 700; }
        QPushButton#primary:hover { background: #c9b9ff; }
        QPushButton:disabled { background: #1c2331; color: #657087; border-color: #293145; }
        QPushButton#primary:disabled { background: #28253c; color: #7e739d; }
        QCheckBox::indicator { width: 23px; height: 23px; border: 1px solid #62708a; border-radius: 6px; background: #111827; }
        QCheckBox::indicator:checked { background: #b6a0ff; border: 4px solid #67518e; }
        QScrollArea { border: none; }
        QScrollBar:vertical { background: #101521; width: 9px; }
        QScrollBar::handle:vertical { background: #3b4762; border-radius: 4px; min-height: 30px; }
        QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
        QToolTip { background: #28324a; color: white; border: 1px solid #66758e; }
    )");
    auto central = new QWidget;
    setCentralWidget(central);
    auto outer = new QHBoxLayout(central);
    outer->setContentsMargins(0, 0, 0, 0);
    outer->setSpacing(0);
    auto sidebar = new QFrame;
    sidebar->setObjectName("sidebar");
    sidebar->setFixedWidth(215);
    auto side = new QVBoxLayout(sidebar);
    side->setContentsMargins(0, 30, 0, 24);
    auto brand = new QLabel("  ◈  Hyprland");
    brand->setObjectName("brand");
    side->addWidget(brand);
    auto sub = new QLabel("      YOUR DESKTOP, YOUR WAY");
    sub->setObjectName("muted");
    sub->setStyleSheet("font-size: 9px; letter-spacing: 1px;");
    side->addWidget(sub);
    side->addSpacing(28);
    navigation = new QListWidget;
    navigation->setObjectName("navigation");
    const QStringList names = {"Appearance", "Effects", "Input", "Layout", "Displays"};
    navigation->addItems(names);
    side->addWidget(navigation);
    auto footer = new QLabel("  Native Qt 6\n  Hyprland · Lua configuration");
    footer->setObjectName("muted");
    side->addWidget(footer);
    outer->addWidget(sidebar);
    auto content = new QVBoxLayout;
    content->setContentsMargins(30, 28, 30, 22);
    content->setSpacing(15);
    auto heading = new QLabel("Appearance");
    heading->setObjectName("heading");
    content->addWidget(heading);
    auto subtitle = new QLabel("Make your workspace feel like home.");
    subtitle->setObjectName("muted");
    content->addWidget(subtitle);
    search = new QLineEdit;
    search->setObjectName("search");
    search->setPlaceholderText("Search settings in this section…");
    search->setClearButtonEnabled(true);
    content->addWidget(search);
    pages = new QStackedWidget;
    for (const auto& name : names) {
        auto page = new QWidget;
        auto layout = new QVBoxLayout(page);
        layout->setContentsMargins(0, 0, 8, 0);
        layout->setSpacing(10);
        if (name == "Displays") displayLayout = layout;
        for (const auto& setting : settings()) {
            if (setting.page != name) continue;
            auto card = new QFrame;
            card->setObjectName("card");
            card->setProperty("searchText", setting.title + " " + setting.description + " " + setting.key);
            auto row = new QHBoxLayout(card);
            row->setContentsMargins(18, 14, 18, 14);
            auto labels = new QVBoxLayout;
            auto title = new QLabel(setting.title);
            title->setStyleSheet("font-weight: 600; font-size: 14px;");
            labels->addWidget(title);
            auto description = new QLabel(setting.description);
            description->setObjectName("muted");
            description->setWordWrap(true);
            labels->addWidget(description);
            row->addLayout(labels, 1);
            row->addSpacing(14);
            QWidget* editor;
            if (setting.type == "bool") {
                auto widget = new QCheckBox("Enabled");
                connect(widget, &QCheckBox::toggled, this, [this] { updateState(); });
                editor = widget;
            } else if (setting.type == "int") {
                auto widget = new QSpinBox;
                widget->setRange(setting.minimum, setting.maximum);
                connect(widget, &QSpinBox::valueChanged, this, [this] { updateState(); });
                editor = widget;
            } else if (setting.type == "float") {
                auto widget = new QDoubleSpinBox;
                widget->setRange(setting.minimum, setting.maximum);
                widget->setDecimals(4);
                widget->setSingleStep(setting.step);
                connect(widget, &QDoubleSpinBox::valueChanged, this, [this] { updateState(); });
                editor = widget;
            } else if (setting.type == "choice" || setting.type == "enum") {
                auto widget = new QComboBox;
                widget->addItems(setting.choices);
                connect(widget, &QComboBox::currentIndexChanged, this, [this] { updateState(); });
                editor = widget;
            } else {
                auto widget = new QLineEdit;
                widget->setMaxLength(20);
                connect(widget, &QLineEdit::textChanged, this, [this] { updateState(); });
                editor = widget;
            }
            editor->setObjectName(setting.key);
            editor->setAccessibleName(setting.title);
            editor->setToolTip(setting.key);
            editor->setFixedWidth(165);
            editors[setting.key] = editor;
            row->addWidget(editor);
            layout->addWidget(card);
            rows[name].append(card);
        }
        layout->addStretch();
        auto scroll = new QScrollArea;
        scroll->setWidgetResizable(true);
        scroll->setWidget(page);
        pages->addWidget(scroll);
    }
    content->addWidget(pages, 1);
    count = new QLabel;
    count->setObjectName("muted");
    content->addWidget(count);
    status = new QLabel("Connecting to Hyprland…");
    status->setObjectName("status");
    status->setWordWrap(true);
    status->setTextFormat(Qt::PlainText);
    status->setStyleSheet("color: #9bcac3;");
    content->addWidget(status);
    auto actions = new QHBoxLayout;
    auto refresh = new QPushButton("Refresh");
    refresh->setObjectName("refresh");
    undoButton = new QPushButton("Undo session");
    undoButton->setObjectName("undo");
    applyButton = new QPushButton("Apply for session");
    applyButton->setObjectName("apply");
    saveButton = new QPushButton("Save permanently");
    saveButton->setObjectName("primary");
    actions->addWidget(refresh);
    actions->addWidget(undoButton);
    actions->addStretch();
    actions->addWidget(applyButton);
    actions->addWidget(saveButton);
    content->addLayout(actions);
    outer->addLayout(content, 1);
    connect(navigation, &QListWidget::currentRowChanged, this, [=](int index) {
        pages->setCurrentIndex(index);
        heading->setText(names.value(index));
        const QStringList descriptions = {"Make your workspace feel like home.", "A little depth. A little motion. Your balance.", "Tune the way you interact with your desktop.", "Give every window its place.", "Your connected screens, at a glance."};
        subtitle->setText(descriptions.value(index));
        search->clear();
        search->setVisible(index != 4);
    });
    connect(search, &QLineEdit::textChanged, this, [this](const QString& query) {
        for (const auto& group : rows) for (auto row : group)
            row->setVisible(row->property("searchText").toString().contains(query, Qt::CaseInsensitive));
    });
    connect(refresh, &QPushButton::clicked, this, [this] {
        if (!changes().isEmpty() && QMessageBox::question(this, "Discard edits?", "Refresh will discard your unapplied edits. Continue?") != QMessageBox::Yes) return;
        load();
    });
    connect(applyButton, &QPushButton::clicked, this, [this] { apply(false); });
    connect(saveButton, &QPushButton::clicked, this, [this] { apply(true); });
    connect(undoButton, &QPushButton::clicked, this, [this] { undo(); });
    navigation->setCurrentRow(0);
    load();
}

QVariant Window::value(const Setting& setting) const {
    auto editor = editors.value(setting.key);
    if (auto box = qobject_cast<QCheckBox*>(editor)) return box->isChecked();
    if (auto spin = qobject_cast<QSpinBox*>(editor)) return spin->value();
    if (auto spin = qobject_cast<QDoubleSpinBox*>(editor)) return spin->value();
    if (auto combo = qobject_cast<QComboBox*>(editor)) {
        if (setting.type == "enum") return combo->currentIndex();
        return combo->currentText();
    }
    return qobject_cast<QLineEdit*>(editor)->text().simplified();
}

void Window::setValue(const Setting& setting, const QVariant& value) {
    auto editor = editors.value(setting.key);
    if (auto box = qobject_cast<QCheckBox*>(editor)) box->setChecked(value.toBool());
    else if (auto spin = qobject_cast<QSpinBox*>(editor)) {
        spin->setRange(qMin(int(setting.minimum), value.toInt()), qMax(int(setting.maximum), value.toInt()));
        spin->setValue(value.toInt());
    } else if (auto spin = qobject_cast<QDoubleSpinBox*>(editor)) {
        spin->setRange(qMin(setting.minimum, value.toDouble()), qMax(setting.maximum, value.toDouble()));
        spin->setValue(value.toDouble());
    } else if (auto combo = qobject_cast<QComboBox*>(editor)) {
        if (setting.type == "enum") combo->setCurrentIndex(value.toInt());
        else {
            if (combo->findText(value.toString()) < 0) combo->addItem(value.toString());
            combo->setCurrentText(value.toString());
        }
    } else qobject_cast<QLineEdit*>(editor)->setText(value.toString());
}

Values Window::changes() const {
    Values result;
    if (current.isEmpty()) return result;
    for (const auto& setting : settings()) {
        const auto candidate = value(setting);
        if (candidate != current.value(setting.key)) result[setting.key] = candidate;
    }
    return result;
}

void Window::updateState() {
    if (loading) return;
    const auto edits = changes();
    count->setText(QString("%1 pending edit%2 · %3 session change%4 not saved").arg(edits.size()).arg(edits.size() == 1 ? "" : "s").arg(session.size()).arg(session.size() == 1 ? "" : "s"));
    applyButton->setEnabled(!edits.isEmpty());
    saveButton->setEnabled(!current.isEmpty() && (!edits.isEmpty() || !session.isEmpty()));
    undoButton->setEnabled(!session.isEmpty());
}

void Window::error(const QString& message) {
    status->setText(message);
    status->setStyleSheet("color: #f5b6bf;");
}

void Window::load() {
    loading = true;
    try {
        current = backend.read();
        for (const auto& setting : settings()) {
            setValue(setting, current.value(setting.key));
            // Compare edits with what the widget can represent, preserving live precision unless edited.
            current[setting.key] = value(setting);
        }
        pages->setEnabled(true);
        status->setText("Connected · Changes take effect when you apply or save.");
        status->setStyleSheet("color: #9bcac3;");
        while (displayLayout->count() > 1) {
            auto item = displayLayout->takeAt(0);
            delete item->widget();
            delete item;
        }
        try {
            for (const auto& entry : backend.monitors()) {
                const auto monitor = entry.toObject();
                auto label = new QLabel(QString("%1\n\n%2\n%3 × %4   ·   %5 Hz\nScale %6×   ·   Position %7, %8\n\nDisplay information is read-only.")
                    .arg(monitor["name"].toString(), monitor["description"].toString())
                    .arg(monitor["width"].toInt()).arg(monitor["height"].toInt())
                    .arg(monitor["refreshRate"].toDouble(), 0, 'f', 2).arg(monitor["scale"].toDouble())
                    .arg(monitor["x"].toInt()).arg(monitor["y"].toInt()));
                label->setTextFormat(Qt::PlainText);
                label->setStyleSheet("background: #192132; padding: 26px; border-radius: 12px; font-size: 16px;");
                label->setWordWrap(true);
                displayLayout->insertWidget(displayLayout->count() - 1, label);
            }
        } catch (const std::exception& e) { error(e.what()); }
    } catch (const std::exception& e) {
        current.clear();
        pages->setEnabled(false);
        error(QString("Cannot connect. Run this app inside your Hyprland session, then Refresh.\n") + e.what());
    }
    loading = false;
    updateState();
}

void Window::apply(bool permanent) {
    const auto edits = changes();
    Values before;
    try {
        for (auto it = edits.cbegin(); it != edits.cend(); ++it)
            before[it.key()] = readValue(backend.run({"-j", "getoption", it.key()}));
        backend.apply(edits);
        for (auto it = before.cbegin(); it != before.cend(); ++it)
            if (!session.contains(it.key())) session[it.key()] = it.value();
        QString backup;
        if (permanent) {
            Values persistent;
            for (auto it = session.cbegin(); it != session.cend(); ++it)
                persistent[it.key()] = readValue(backend.run({"-j", "getoption", it.key()}));
            backup = saveConfig(configPath, persistent);
            session.clear();
        }
        load();
        status->setText(permanent ? "Saved. Backup: " + backup : "Applied for this session. Save permanently to keep changes after reload.");
    } catch (const std::exception& e) {
        // Applied values remain undoable when persistence fails.
        load();
        error(e.what());
    }
    updateState();
}

void Window::undo() {
    try {
        backend.apply(session);
        session.clear();
        load();
        status->setText("Previous session settings restored.");
    } catch (const std::exception& e) { error(e.what()); }
    updateState();
}

void Window::closeEvent(QCloseEvent* event) {
    if (!changes().isEmpty() || !session.isEmpty()) {
        auto answer = QMessageBox::question(this, "Close settings?", "There are unsaved changes. Closing discards pending edits; applied session changes stay active until Hyprland reloads. Close anyway?", QMessageBox::Yes | QMessageBox::No, QMessageBox::No);
        if (answer != QMessageBox::Yes) { event->ignore(); return; }
    }
    event->accept();
}
