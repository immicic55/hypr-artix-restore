#!/bin/sh
set -eu
cd "$(dirname "$0")"
data_dir="${XDG_DATA_HOME:-$HOME/.local/share}"
bin_dir="$HOME/.local/bin"
install -Dm755 hypr-settings "$bin_dir/hypr-settings"
install -Dm644 hypr-settings.svg "$data_dir/icons/hicolor/scalable/apps/hypr-settings.svg"
mkdir -p "$data_dir/applications"
cat > "$data_dir/applications/hypr-settings.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Hyprland Settings
Comment=Customize appearance, effects, input and tiling
Exec="$bin_dir/hypr-settings"
Icon=hypr-settings
Terminal=false
Categories=Settings;DesktopSettings;Qt;
Keywords=Hyprland;Wayland;Appearance;Input;
StartupWMClass=hypr-settings
EOF
if command -v update-desktop-database >/dev/null 2>&1; then
    update-desktop-database "$data_dir/applications"
fi
echo "Installed $bin_dir/hypr-settings"
