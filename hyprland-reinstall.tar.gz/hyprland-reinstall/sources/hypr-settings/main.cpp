#include "window.h"

int main(int argc, char** argv) {
    QApplication app(argc, argv);
    app.setApplicationName("hypr-settings");
    app.setDesktopFileName("hypr-settings");
    app.setOrganizationName("LocalDesktop");
    QCommandLineParser parser;
    parser.setApplicationDescription("Native Qt 6 settings for Hyprland with Lua configuration.");
    parser.addHelpOption();
    parser.addOption({"config", "Lua config file to save.", "path"});
    parser.addOption({"smoke-test", "Read settings, render a screenshot and exit without changes.", "image"});
    parser.process(app);
    Window window(Backend(), parser.value("config"));
    window.show();
    if (parser.isSet("smoke-test")) {
        QTimer::singleShot(1000, &app, [&] {
            const bool connected = window.findChild<QStackedWidget*>()->isEnabled();
            const bool saved = window.grab().save(parser.value("smoke-test"));
            app.exit(connected && saved ? 0 : 1);
        });
    }
    return app.exec();
}
