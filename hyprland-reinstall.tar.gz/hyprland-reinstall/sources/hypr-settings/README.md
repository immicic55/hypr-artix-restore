# Hyprland Settings

A native C++ / Qt 6 desktop settings app for Hyprland's Lua configuration.
Built and tested on Hyprland 0.56.2 and Qt 6.11.2.

22 controls cover window gaps, borders, corners, opacity, blur, shadows,
animations, pointer behavior, touchpad preferences, keyboard repeat, and tiling.
The Displays page shows connected monitor information (read-only). Search filters
the current section. Unsupported or disconnected sessions show a connection error.

## Launch

Open **Hyprland Settings** in your application launcher, or run:

```sh
~/.local/bin/hypr-settings
```

## Changes and backups

- **Apply for session** updates only edited settings. Values are read back to
  check the result; failed updates attempt to restore the previous values.
- **Undo session** restores the values from before this app's session changes.
- **Save permanently** applies changes and appends/updates a marked block at the
  end of `$XDG_CONFIG_HOME/hypr/hyprland.lua` (normally `~/.config/hypr/hyprland.lua`).
  Other config content is retained. A timestamped `.backup-*` file is written
  alongside the config before each atomic save. If saving fails after applying,
  the app keeps the session changes available for Undo.
- **Refresh** rereads current values and discards unapplied edits after confirmation.
- Closing the app leaves applied session changes active. They reset on a
  compositor config reload unless saved permanently.

The app targets Lua configs, not older `.conf` configurations. If your session uses
a custom Lua config path, launch with `--config /path/to/hyprland.lua`.
Monitor mode changes, keybindings, color themes, and per-device overrides are not
edited by this version. Per-device overrides may take precedence over global input
settings. Runtime IPC uses the documented
[Hyprland Lua configuration API](https://wiki.hypr.land/configuring/core/config-options/).

## Build and install

Requires a C++17 compiler, make, qmake6, Qt 6 Widgets, and hyprctl.

```sh
qmake6 hypr-settings.pro
make -j2
sh install.sh
```

## Tests

Qt Test is also required. Offline tests use a fake compositor and temporary files:

```sh
cd tests
qmake6 tests.pro
make -j2
QT_QPA_PLATFORM=offscreen ./test-settings
```

Opt-in integration testing must run inside a live Hyprland session. It exercises
reading all controls, reapplying their current values, clicking Apply and Undo,
saving to a temporary Lua config, and evaluating that config. It briefly changes
corner rounding and restores all original values using a scope guard. It does
not write the real desktop config.

```sh
QT_QPA_PLATFORM=offscreen HYPR_SETTINGS_LIVE_TEST=1 ./test-settings
```

Render the actual app without changing settings:

```sh
./hypr-settings --smoke-test screenshot.png
```

`tests/test-results.txt` and `tests/live-test-results.txt` contain the test reports.
