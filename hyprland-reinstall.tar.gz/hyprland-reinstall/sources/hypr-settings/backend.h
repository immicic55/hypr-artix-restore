#pragma once
#include <QtCore>
#include <functional>

struct Setting {
    QString key, title, description, page, type;
    double minimum = 0, maximum = 1, step = 1;
    QStringList choices = {};
};
const QList<Setting>& settings();
using Values = QMap<QString, QVariant>;
using Runner = std::function<QByteArray(const QStringList&)>;
QByteArray runHyprctl(const QStringList& args);
QVariant readValue(const QByteArray& json);
QString luaValue(const QVariant& value);
QString luaConfig(const Values& values);
QByteArray mergeConfig(const QByteArray& original, const Values& changes);
QString saveConfig(const QString& path, const Values& changes);

class Backend {
public:
    explicit Backend(Runner runner = runHyprctl) : run(std::move(runner)) {}
    Values read();
    void apply(const Values& changes);
    QJsonArray monitors();
    Runner run;
};
