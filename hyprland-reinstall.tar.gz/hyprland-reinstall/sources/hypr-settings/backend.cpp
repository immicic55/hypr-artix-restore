#include "backend.h"
#include <stdexcept>

static void fail(const QString& message) { throw std::runtime_error(message.toStdString()); }

const QList<Setting>& settings() {
    static const QList<Setting> list = {
        {"general:gaps_in", "Inner gaps", "Space between windows. One value, or top right bottom left.", "Appearance", "gaps", 0, 100},
        {"general:gaps_out", "Outer gaps", "Space around the workspace. One value, or top right bottom left.", "Appearance", "gaps", 0, 200},
        {"general:border_size", "Border width", "Window border thickness in pixels.", "Appearance", "int", 0, 10},
        {"decoration:rounding", "Corner radius", "Round the corners of your windows.", "Appearance", "int", 0, 50},
        {"decoration:active_opacity", "Focused opacity", "Opacity of the active window.", "Appearance", "float", 0.2, 1, 0.05},
        {"decoration:inactive_opacity", "Unfocused opacity", "Opacity of inactive windows.", "Appearance", "float", 0.2, 1, 0.05},
        {"decoration:blur:enabled", "Background blur", "Blur content behind transparent windows.", "Effects", "bool"},
        {"decoration:blur:size", "Blur size", "Radius of each blur pass.", "Effects", "int", 1, 20},
        {"decoration:blur:passes", "Blur passes", "More passes produce softer blur and use more GPU time.", "Effects", "int", 1, 6},
        {"decoration:shadow:enabled", "Window shadows", "Add depth around floating and tiled windows.", "Effects", "bool"},
        {"decoration:shadow:range", "Shadow range", "How far the shadow extends in pixels.", "Effects", "int", 0, 100},
        {"animations:enabled", "Animations", "Animate windows and workspace transitions.", "Effects", "bool"},
        {"input:sensitivity", "Pointer sensitivity", "Adjust mouse movement speed.", "Input", "float", -1, 1, 0.05},
        {"input:follow_mouse", "Focus follows pointer", "Choose how pointer movement changes focus.", "Input", "enum", 0, 3, 1, {"Click to focus", "Follow pointer", "Loose follow", "Strict follow"}},
        {"input:touchpad:natural_scroll", "Natural scrolling", "Scroll content in the direction of your fingers.", "Input", "bool"},
        {"input:touchpad:tap_to_click", "Tap to click", "Use a touchpad tap as a mouse click.", "Input", "bool"},
        {"input:touchpad:disable_while_typing", "Pause touchpad while typing", "Avoid accidental pointer movement while typing.", "Input", "bool"},
        {"input:repeat_delay", "Key repeat delay", "Milliseconds before a held key starts repeating.", "Input", "int", 100, 2000},
        {"input:repeat_rate", "Key repeat rate", "Repeated characters per second.", "Input", "int", 1, 100},
        {"general:layout", "Tiling layout", "Choose the layout used to arrange your windows.", "Layout", "choice", 0, 1, 1, {"dwindle", "master", "scrolling"}},
        {"general:resize_on_border", "Resize at borders", "Drag a window border to resize it.", "Layout", "bool"},
        {"dwindle:preserve_split", "Preserve split direction", "Keep the split direction when rearranging windows.", "Layout", "bool"},
    };
    return list;
}

QByteArray runHyprctl(const QStringList& args) {
    QProcess process;
    process.start("hyprctl", args);
    if (!process.waitForStarted(2000)) fail("Cannot start hyprctl. Is Hyprland installed?");
    if (!process.waitForFinished(5000)) { process.kill(); process.waitForFinished(); fail("Hyprland did not respond within 5 seconds."); }
    const auto output = process.readAllStandardOutput();
    if (process.exitStatus() != QProcess::NormalExit || process.exitCode() != 0)
        fail("Hyprland: " + QString::fromUtf8(output + process.readAllStandardError()).trimmed());
    return output;
}

QVariant readValue(const QByteArray& json) {
    QJsonParseError error;
    const auto doc = QJsonDocument::fromJson(json, &error);
    if (error.error != QJsonParseError::NoError || !doc.isObject()) fail("Invalid settings response from Hyprland.");
    const auto object = doc.object();
    for (const auto& key : {"bool", "int", "float", "str", "css"})
        if (object.contains(key)) return object.value(key).toVariant();
    fail("Hyprland did not return a supported setting value.");
    return {};
}

QString luaValue(const QVariant& value) {
    if (value.metaType().id() == QMetaType::Bool) return value.toBool() ? "true" : "false";
    if (value.metaType().id() == QMetaType::QString) {
        const auto string = value.toString();
        QString result = "\"";
        for (const QChar ch : string) {
            if (ch == '\\' || ch == '"') result += '\\';
            if (ch.unicode() < 32) fail("Control characters are not allowed in settings.");
            result += ch;
        }
        return result + '"';
    }
    bool ok;
    const double number = value.toDouble(&ok);
    if (!ok || !qIsFinite(number)) fail("Invalid numeric setting.");
    return QString::number(number, 'g', 16);
}

static void validate(const QString& key, const QVariant& value) {
    for (const auto& setting : settings()) {
        if (setting.key != key) continue;
        if (setting.type == "gaps") {
            if (!QRegularExpression("^\\d{1,3}(?: +\\d{1,3}){0,3}$").match(value.toString()).hasMatch())
                fail(setting.title + ": enter one to four positive pixel values.");
            for (const auto& part : value.toString().split(' ', Qt::SkipEmptyParts))
                if (part.toInt() > setting.maximum) fail(setting.title + ": value is too large.");
        } else if (setting.type == "choice") {
            if (!setting.choices.contains(value.toString())) fail("Unknown layout.");
        } else if (setting.type == "bool") {
            if (value.metaType().id() != QMetaType::Bool) fail("Invalid boolean value.");
        } else {
            bool ok;
            double number = value.toDouble(&ok);
            if (!ok || !qIsFinite(number) || number < setting.minimum || number > setting.maximum)
                fail(setting.title + ": value is out of range.");
            if (setting.type != "float" && number != qFloor(number)) fail("Expected a whole number.");
        }
        return;
    }
    fail("Unknown setting: " + key);
}

static QString settingLiteral(const QString& key, const QVariant& value) {
    if (key == "general:gaps_in" || key == "general:gaps_out") {
        auto parts = value.toString().split(' ', Qt::SkipEmptyParts);
        if (parts.size() == 1) return QString::number(parts[0].toInt());
        if (parts.size() == 2) parts = {parts[0], parts[1], parts[0], parts[1]};
        if (parts.size() == 3) parts.append(parts[1]);
        if (parts.size() != 4) fail("Invalid gap values.");
        return QString("{ top = %1, right = %2, bottom = %3, left = %4 }")
            .arg(parts[0].toInt()).arg(parts[1].toInt()).arg(parts[2].toInt()).arg(parts[3].toInt());
    }
    return luaValue(value);
}

QString luaConfig(const Values& values) {
    QString result;
    for (auto it = values.cbegin(); it != values.cend(); ++it) {
        validate(it.key(), it.value());
        QString expression = settingLiteral(it.key(), it.value());
        auto parts = it.key().split(':');
        for (auto p = parts.crbegin(); p != parts.crend(); ++p)
            expression = "{ " + *p + " = " + expression + " }";
        result += "hl.config(" + expression + ")\n";
    }
    return result;
}

static const QByteArray beginMarker = "-- BEGIN HYPR-SETTINGS MANAGED BLOCK";
static const QByteArray endMarker = "-- END HYPR-SETTINGS MANAGED BLOCK";

QByteArray mergeConfig(const QByteArray& original, const Values& changes) {
    QByteArray base = original;
    Values merged;
    const auto begin = original.indexOf(beginMarker), end = original.indexOf(endMarker);
    if (begin >= 0 || end >= 0) {
        if (begin < 0 || end < begin || original.indexOf(beginMarker, begin + 1) >= 0 || original.indexOf(endMarker, end + 1) >= 0)
            fail("The managed settings block is damaged. Restore the config backup before saving.");
        const auto jsonStart = begin + beginMarker.size() + 1;
        const auto jsonEnd = original.indexOf('\n', jsonStart);
        if (original.mid(jsonStart, 3) != "-- ") fail("Missing managed settings metadata.");
        QJsonParseError error;
        const auto doc = QJsonDocument::fromJson(original.mid(jsonStart + 3, jsonEnd - jsonStart - 3), &error);
        if (error.error != QJsonParseError::NoError || !doc.isObject()) fail("Invalid managed settings metadata.");
        const auto obj = doc.object();
        for (auto it = obj.begin(); it != obj.end(); ++it) merged[it.key()] = it.value().toVariant();
        base.remove(begin, end + endMarker.size() - begin);
    }
    for (auto it = changes.cbegin(); it != changes.cend(); ++it) merged[it.key()] = it.value();
    QJsonObject object;
    for (auto it = merged.cbegin(); it != merged.cend(); ++it) object[it.key()] = QJsonValue::fromVariant(it.value());
    const auto code = luaConfig(merged).toUtf8();
    while (base.endsWith('\n')) base.chop(1);
    return base + "\n\n" + beginMarker + "\n-- " + QJsonDocument(object).toJson(QJsonDocument::Compact) + "\n" + code + endMarker + "\n";
}

QString saveConfig(const QString& path, const Values& changes) {
    QLockFile lock(path + ".hypr-settings.lock");
    if (!lock.tryLock(0)) fail("Another settings app is saving this config.");
    QFile source(path);
    if (!source.open(QIODevice::ReadOnly)) fail("Cannot read " + path + ": " + source.errorString());
    const auto original = source.readAll();
    source.close();
    const auto updated = mergeConfig(original, changes);
    const QString backup = path + ".backup-" + QDateTime::currentDateTimeUtc().toString("yyyyMMdd-HHmmss-zzz");
    if (!QFile::copy(path, backup)) fail("Cannot create a config backup. Nothing was saved.");
    QSaveFile target(path);
    if (!target.open(QIODevice::WriteOnly) || target.write(updated) != updated.size() || !target.commit())
        fail("Cannot save config: " + target.errorString());
    return backup;
}

Values Backend::read() {
    Values result;
    for (const auto& setting : settings()) result[setting.key] = readValue(run({"-j", "getoption", setting.key}));
    return result;
}

void Backend::apply(const Values& changes) {
    if (changes.isEmpty()) return;
    const auto script = luaConfig(changes);
    Values previous;
    for (auto it = changes.cbegin(); it != changes.cend(); ++it)
        previous[it.key()] = readValue(run({"-j", "getoption", it.key()}));
    const auto restore = [&]() {
        QString code;
        // Preserve even pre-existing values outside this app's editable range.
        for (auto it = previous.cbegin(); it != previous.cend(); ++it) {
            auto parts = it.key().split(':');
            auto expression = settingLiteral(it.key(), it.value());
            for (auto p = parts.crbegin(); p != parts.crend(); ++p) expression = "{ " + *p + " = " + expression + " }";
            code += "hl.config(" + expression + ")\n";
        }
        const auto reply = run({"eval", code}).trimmed();
        if (reply != "ok") fail("Rollback failed: " + QString::fromUtf8(reply));
    };
    try {
        const auto reply = run({"eval", script}).trimmed();
        if (reply != "ok") fail(QString::fromUtf8(reply));
        for (auto it = changes.cbegin(); it != changes.cend(); ++it) {
            const auto current = readValue(run({"-j", "getoption", it.key()}));
            if (it.key().startsWith("general:gaps_")) {
                auto parts = it.value().toString().split(' ', Qt::SkipEmptyParts);
                if (parts.size() == 1) parts = {parts[0], parts[0], parts[0], parts[0]};
                else if (parts.size() == 2) parts = {parts[0], parts[1], parts[0], parts[1]};
                else if (parts.size() == 3) parts.append(parts[1]);
                if (current.toString() != parts.join(' ')) fail("Hyprland did not accept " + it.key());
            } else if (current != it.value()) fail("Hyprland did not accept " + it.key());
        }
    } catch (const std::exception& e) {
        const QString original = QString::fromUtf8(e.what());
        try { restore(); } catch (const std::exception& rollback) { fail(original + "\n" + rollback.what()); }
        fail(original + "\nPrevious session values restored.");
    }
}

QJsonArray Backend::monitors() {
    const auto doc = QJsonDocument::fromJson(run({"-j", "monitors"}));
    if (!doc.isArray()) fail("Invalid display response from Hyprland.");
    return doc.array();
}
