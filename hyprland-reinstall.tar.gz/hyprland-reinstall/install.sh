#!/usr/bin/env bash
set -euo pipefail
bundle=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
mode=${1:---install}
case "$mode" in --install|--dry-run) ;; *) echo 'Usage: bash install.sh [--dry-run]'; exit 2;; esac
[[ $EUID -ne 0 ]] || { echo 'Run as your normal user without sudo; the script uses sudo where needed.' >&2; exit 1; }
[[ $(uname -m) == x86_64 ]] || { echo 'This snapshot is for x86_64 Artix.' >&2; exit 1; }
command -v pacman >/dev/null
mapfile -t native < <(cat "$bundle/packages-repo.txt" "$bundle/packages-desktop.txt" | sed '/^$/d' | LC_ALL=C sort -u)
mapfile -t foreign < "$bundle/packages-foreign.txt"
printf 'Saved explicitly installed packages: %s\nRepository install/reinstall targets, including desktop dependencies: %s\nForeign packages: %s\n' "$(wc -l < "$bundle/packages-explicit.txt")" "${#native[@]}" "${foreign[*]}"
(cd "$bundle"; sha256sum -c SHA256SUMS >/dev/null)
if [[ $mode == --dry-run ]]; then
 printf '\nRepository targets:\n';printf '%s\n' "${native[@]}"
 printf '\nAlso restores Sober (Flatpak), @openai/codex (npm), google-colab-cli (uv), and /usr/local/bin/fetch.\n'
 printf '\nPlan: full system upgrade and reinstall targets; reinstall foreign packages; rebuild both Hyprland plugins and settings app; back up and restore desktop; enable OpenRC services.\n'
 exit 0
fi
[[ -f /etc/artix-release ]] || { echo 'This installer targets Artix Linux.' >&2; exit 1; }
sudo -v
# -Syu keeps the system consistent and reinstalls each named target.
# Do not use --needed: reinstalling existing explicit packages is intentional.
sudo pacman -Syu -- "${native[@]}"
failed=()
if ! command -v yay >/dev/null; then
 work=$(mktemp -d)
 git clone https://aur.archlinux.org/yay.git "$work/yay"
 (cd "$work/yay"; makepkg -si)
 rm -rf -- "$work"
fi
for package in "${foreign[@]}"; do
 [[ -n $package ]] || continue
 # Keep normal PKGBUILD review and package-manager prompts enabled.
 if ! yay -S -- "$package"; then failed+=("$package"); fi
done
stage=$(mktemp -d)
trap 'rm -rf -- "$stage"' EXIT
cp -a "$bundle/payload" "$stage/payload"
jobs=${JOBS:-2}
[[ $jobs =~ ^[1-9][0-9]*$ ]] || { echo 'JOBS must be a positive integer.' >&2; exit 1; }
cmake -S "$bundle/sources/spatial-overview" -B "$stage/spatial-build" -DCMAKE_BUILD_TYPE=Release
cmake --build "$stage/spatial-build" -j "$jobs"
install -m755 "$stage/spatial-build/libspatialoverview.so" "$stage/payload/.local/share/spatial-overview/spatialoverview.so"
(cd "$stage/payload/.local/share/hypr-unlock-reveal"; bash build.sh)
mkdir "$stage/settings-build"
(cd "$stage/settings-build"; qmake6 "$bundle/sources/hypr-settings/hypr-settings.pro"; make -j "$jobs")
install -m755 "$stage/settings-build/hypr-settings" "$stage/payload/.local/bin/hypr-settings"
python3 "$bundle/restore-config.py" --payload "$stage/payload"
system_backup="$HOME/.local/state/hyprland-reinstall/system-backup-$(date +%Y%m%d-%H%M%S)-$$"
mkdir -p "$system_backup"
for path in /usr/local/bin/hypr-artix-session /usr/share/wayland-sessions/hyprland-artix.desktop /usr/local/bin/fetch; do
 if [[ -e $path ]]; then
  mkdir -p "$system_backup$(dirname "$path")"
  cp -- "$path" "$system_backup$path"
 fi
done
sudo install -Dm755 "$bundle/system/usr/local/bin/fetch" /usr/local/bin/fetch
# The packaged recorder is rebuilt for current libraries; use it in preference
# to the older local binary while retaining that binary in the snapshot.
rm -f -- "$HOME/.local/bin/wf-recorder"
sudo install -Dm755 "$HOME/.local/bin/hypr-session" /usr/local/bin/hypr-artix-session
sudo install -Dm644 "$HOME/.local/share/artix-desktop/hyprland-artix.desktop" /usr/share/wayland-sessions/hyprland-artix.desktop
sudo rc-update add dbus default
sudo rc-update add elogind boot
sudo rc-update add NetworkManager default
sudo rc-update add sddm default
rc-update --user add pipewire default
Hyprland --verify-config -c "$HOME/.config/hypr/hyprland.lua"
while read -r package; do
 [[ -n $package ]] || continue
 sudo npm install -g -- "$package" || failed+=("npm:$package")
done < "$bundle/packages-npm.txt"
while read -r package; do
 [[ -n $package ]] || continue
 uv tool install --force "$package" || failed+=("uv:$package")
done < "$bundle/packages-uv.txt"
# Preserve the original system-wide Flatpak installation scope.
sudo flatpak remote-add --if-not-exists flathub https://flathub.org/repo/flathub.flatpakrepo
while read -r app remote scope; do
 [[ -n $app ]] || continue
 if [[ $scope == system ]]; then
  sudo flatpak install --reinstall --system "$remote" "$app" || failed+=("flatpak:$app")
 else
  flatpak install --reinstall --user "$remote" "$app" || failed+=("flatpak:$app")
 fi
done < "$bundle/packages-flatpak.txt"
printf '\nDesktop and PipeWire installed. Log out and select Hyprland (Artix desktop), or reboot when ready.\n'
if ((${#failed[@]})); then
 printf 'These package installs still need attention: %s\n' "${failed[*]}" >&2
 exit 1
fi
printf 'All saved explicitly installed packages were processed successfully.\n'
