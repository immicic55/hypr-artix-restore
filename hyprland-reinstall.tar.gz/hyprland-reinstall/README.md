This bundle restores maiake's Artix/OpenRC Hyprland desktop from the saved snapshot and reinstalls all 75 packages marked explicitly installed by pacman. The package list contains 71 official-repository packages and four foreign packages: cloudflare-warp-bin, termius, warp-svc-openrc and yay. Dependencies are resolved by the package manager. Repository packages are upgraded to the current repository versions and reinstalled; this is not a version-pinned offline recovery image.

Run as your normal user, without sudo:

```bash
bash ~/hyprland-reinstall/install.sh --dry-run
bash ~/hyprland-reinstall/install.sh
```

Keep this whole directory (or its archive), since install.sh reads the included configs, package lists and source files. It requires an existing x86_64 Artix installation with pacman, sudo access, internet access and sufficient disk space. Package-manager prompts and AUR build review remain interactive.

The restore includes Hyprland Lua config, Waybar, Kitty, Fuzzel, Mako, GTK appearance, portal preferences, CAVA, wallpapers, capture/layout helpers, the local settings app and both custom Hyprland plugins. It rebuilds the plugins against the installed Hyprland headers and rebuilds the settings app. The packaged wf-recorder replaces the old locally built recorder. Build concurrency defaults to 2; use JOBS=4 bash install.sh to change it. If a compositor API update breaks the saved plugin source, installation stops before replacing your configs and shows the compiler error.

Every overwritten user path is backed up in ~/.local/state/hyprland-reinstall/backup-TIMESTAMP-PID. Restore replaces the listed desktop paths with the snapshot; unrelated home files remain in place. Hardcoded /home/maiake paths in text configuration are rewritten for the current home directory. Build failures happen before configuration replacement. If a foreign package fails, desktop setup continues and the script exits with a list of unresolved packages.

PipeWire, WirePlumber, ALSA tools, OpenRC user audio service support and the Hyprland login session are installed. The script enables the OpenRC desktop services; it does not restart the running desktop or reboot automatically. After completion, log out and select “Hyprland (Artix desktop)” or reboot when convenient.

Package inventories are snapshots, rather than a claim to identify the original human installer. Pacman's explicit flag is the available record of packages selected directly rather than pulled in as dependencies. Also reinstalls the detected Sober Flatpak (system scope), global npm @openai/codex CLI and uv google-colab-cli tool. Pacman-owned npm/node-gyp/nopt/semver are handled through pacman. The manually installed /usr/local/bin/fetch binary is preserved in system/ and restored with a backup of any existing copy. Other unmanaged software is not automatically discoverable. Current audio experiments and saved audio state are not included. This reinstall is not a confirmed repair for the silent built-in speakers.
